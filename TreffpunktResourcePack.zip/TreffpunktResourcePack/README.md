# Treffpunkt Resource Pack

## Setup

1. **Grafik vorbereiten:**
   - Speichere deine Treffpunkt-Logo-Grafik als `treffpunkt_logo.png`
   - Empfohlene Größe: 128x16 Pixel (Breite x Höhe)
   - Format: PNG mit Transparenz
   - Speicherort: `assets/minecraft/textures/font/treffpunkt_logo.png`

2. **Resource Pack installieren:**
   - Packe den gesamten Ordner `TreffpunktResourcePack` als ZIP
   - Benenne die ZIP in `TreffpunktResourcePack.zip` um
   - Kopiere sie in deinen Minecraft `resourcepacks` Ordner
   - Aktiviere das Pack im Spiel unter "Options" → "Resource Packs"

3. **Im Code verwenden:**
   - Das Logo wird mit dem Unicode-Zeichen `\uE000` angezeigt
   - Der Code wurde bereits angepasst!

## Anpassungen

- **Größe ändern:** Passe `height` und `ascent` in `default.json` an
- **Position ändern:** Ändere `ascent` (höher = weiter oben)
- **Breite:** Die Breite wird automatisch aus der PNG-Datei berechnet

## Alternative: Mehrere Zeichen

Wenn dein Logo sehr breit ist, kannst du es in mehrere Teile aufteilen:

```json
"chars": [
  "\uE000\uE001\uE002"
]
```

Dann erstelle `treffpunkt_logo_0.png`, `treffpunkt_logo_1.png`, etc.
